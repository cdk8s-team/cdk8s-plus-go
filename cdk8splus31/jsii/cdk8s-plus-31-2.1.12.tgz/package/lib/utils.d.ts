import { IConstruct } from 'constructs';
export declare function undefinedIfEmpty<T>(obj: T): T | undefined;
export declare function filterUndefined(obj: any): any;
export declare function address(...constructs: IConstruct[]): string;
