# cdk8s+ (cdk8s-plus)

### High level constructs for Kubernetes

![Stability:Stable](https://img.shields.io/badge/stability-stable-success)

| k8s version | npm (JS/TS)                                         | PyPI (Python)                                   | Maven (Java)                                                      | Go                                                              |
| ----------- | --------------------------------------------------- | ----------------------------------------------- | ----------------------------------------------------------------- | --------------------------------------------------------------- |
| 1.33.0      | [Link](https://www.npmjs.com/package/cdk8s-plus-33) | [Link](https://pypi.org/project/cdk8s-plus-33/) | [Link](https://search.maven.org/artifact/org.cdk8s/cdk8s-plus-33) | [Link](https://github.com/cdk8s-team/cdk8s-plus-go/tree/k8s.33) |
| 1.34.0      | [Link](https://www.npmjs.com/package/cdk8s-plus-34) | [Link](https://pypi.org/project/cdk8s-plus-34/) | [Link](https://search.maven.org/artifact/org.cdk8s/cdk8s-plus-34) | [Link](https://github.com/cdk8s-team/cdk8s-plus-go/tree/k8s.34) |
| 1.35.0      | [Link](https://www.npmjs.com/package/cdk8s-plus-35) | [Link](https://pypi.org/project/cdk8s-plus-35/) | [Link](https://search.maven.org/artifact/org.cdk8s/cdk8s-plus-35) | [Link](https://github.com/cdk8s-team/cdk8s-plus-go/tree/k8s.35) |

**cdk8s+** is a software development framework that provides high level
abstractions for authoring Kubernetes applications. Built on top of the auto
generated building blocks provided by [cdk8s](../cdk8s), this library includes a
hand crafted _construct_ for each native kubernetes object, exposing richer
API's with reduced complexity.

## :books: Documentation

See [cdk8s.io](https://cdk8s.io/docs/latest/plus).

## :raised_hand: Contributing

If you'd like to add a new feature or fix a bug, please visit
[CONTRIBUTING.md](CONTRIBUTING.md)!

## :balance_scale: License

This project is distributed under the [Apache License, Version 2.0](./LICENSE).

This module is part of the [cdk8s project](https://github.com/cdk8s-team).
